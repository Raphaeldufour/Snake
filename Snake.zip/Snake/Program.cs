﻿using System.Windows.Input;
List<(int, int)> snake = new();
snake.Add((1, 0));
string[,] affichage = new string[20, 20];
int boucle = 0;
(int x, int y) = snake[0];
Random rand = new Random();
(int, int) pomme = (rand.Next(10),rand.Next(10));
ConsoleKeyInfo key=Console.ReadKey();
while (true)
{
	for (int i = 0; i < affichage.GetLength(0); i++)
	{
		for (int j = 0; j < affichage.GetLength(1); j++)
		{

			if (snake.Contains((j, i)))
			{
				Console.Write("X");
				boucle++;
			}
			else if (pomme==(j,i))
			{
				Console.Write("P");
			}
			else
			{
				Console.Write(" ");
			}
		}
		Console.WriteLine();
	}
	
	(x, y) = snake[0];
	if (Console.KeyAvailable)
	{
		key = Console.ReadKey();
	}
	switch (key.Key)
	{
		case ConsoleKey.LeftArrow:
			snake.Insert(0, (x - 1, y));
			break;
		case ConsoleKey.RightArrow:
			snake.Insert(0, (x + 1, y));
			break;
		case ConsoleKey.UpArrow:
			snake.Insert(0, (x, y - 1));
			break;
		case ConsoleKey.DownArrow:
			snake.Insert(0, (x, y + 1));
			break;
		default:
			break;
	}
	if (pomme != snake[0])
	{
		snake.RemoveAt(snake.Count - 1);
	}
	if (pomme==snake[0])
	{
		pomme = (rand.Next(10), rand.Next(10));
	}
	Thread.Sleep(200);
	Console.Clear();
}